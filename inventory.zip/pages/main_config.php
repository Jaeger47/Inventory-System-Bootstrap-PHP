<?php
	//Php Main Config
	$data_name = "itsi";
	$data_name_login = "itsi_login";
	$data_host = "localhost";
	$data_user = "root";
	$data_pass = "";
?>