<?php 

    // First we execute our common code to connection to the database and start the session 
    require("common.php"); 
     
    // At the top of the page we check to see whether the user is logged in or not 
    if(empty($_SESSION['user'])) 
    { 
        // If they are not, we redirect them to the login page. 
        header("Location: index_.php"); 
         
        // Remember that this die statement is absolutely critical.  Without it, 
        // people can view your members-only content without logging in. 
        die("Redirecting to index_.php"); 
    } 
     
    // Everything below this point in the file is secured by the login system 
     
    // We can display the user's username to them by reading it from the session array.  Remember that because 
    // a username is user submitted content we must use htmlentities on it before displaying it to the user. 
?> 
<?php
include_once("startup_config.php");

if(isset($_POST['Sumbit']))
{	

	$id = mysqli_real_escape_string($con, $_POST['id_del']);
	
	$del_date = mysqli_real_escape_string($con, $_POST['del_date']);
	$del_by = mysqli_real_escape_string($con, $_POST['del_by']);
	$remarks = mysqli_real_escape_string($con, $_POST['remarks']);
	$del = mysqli_real_escape_string($con, $_POST['del']);
	
	$name = $_FILES['myfile']['name'];
	$tmp_name = $_FILES['myfile']['tmp_name'];
	$location = "documents/deliver/$name";
	move_uploaded_file($tmp_name, $location);
	
		
	// checking empty fields
	if(empty($del_date) || empty($del_by) || empty($name)) {
		
	    echo"<script>alert(\"Please fill all the Fields\");</script>";		
		echo "<script>window.history.back();</script>";
		
	
	} else {	
		//updating the table
		$result = mysqli_query($con, "UPDATE documents SET del_date='$del_date',del_by='$del_by',remarks='$remarks',del='$del',name_2='$name',path_2='$location',status='Delivered' WHERE id=$id");
		
		header('Location: index.php');	
		
		

		//redirectig to the display page. In our case, it is index.php
	//	header("Location: index.php");
	}
	
}
?>