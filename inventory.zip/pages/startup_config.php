<?php
require 'data_db.php';
$servername = $db_host;
$username = $db_user;
$password = $db_pass;
$db = $db_pdo;
$conn = mysqli_connect($servername, $username, $password);
$sql_itsi = "CREATE DATABASE itsi";
if (mysqli_query($conn, $sql_itsi)) {
    //echo "Database created successfully";
} else {
    //echo "Error creating database: " . mysqli_error($conn);
}
mysqli_close($conn);
$con = mysqli_connect($servername, $username, $password, $db);
if ($con->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql_docu = "CREATE TABLE documents (
id INT(255) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
p_o VARCHAR(100) NOT NULL,
s_o VARCHAR(100) NOT NULL,
del VARCHAR(100) NOT NULL,
rack VARCHAR(100) NOT NULL,
rev_date DATE,
del_date DATE,
del_by VARCHAR(100) NOT NULL,
remarks VARCHAR(100) NOT NULL,
status VARCHAR(100) NOT NULL,
name VARCHAR(100) NOT NULL,
path VARCHAR(100) NOT NULL,
name_2 VARCHAR(100) NOT NULL,
path_2 VARCHAR(100) NOT NULL
)";

$sql_tools = "CREATE TABLE tools (
id INT(255) NOT NULL AUTO_INCREMENT PRIMARY KEY, 
tbl_1 VARCHAR(100) NOT NULL,
tbl_2 VARCHAR(100) NOT NULL,
tbl_3 VARCHAR(100) NOT NULL,
tbl_4 VARCHAR(100) NOT NULL,
tbl_5 VARCHAR(100) NOT NULL,
tbl_6 VARCHAR(100) NOT NULL,
tbl_7 VARCHAR(100) NOT NULL,
tbl_8 VARCHAR(100) NOT NULL,
tbl_9 VARCHAR(100) NOT NULL,
tbl_10 VARCHAR(100) NOT NULL
)";

$sql_main = "CREATE TABLE main (
id INT(255) NOT NULL AUTO_INCREMENT PRIMARY KEY,
id_tools INT(255) NOT NULL,
tol_date DATE,
rev_date VARCHAR(100),
bor_by VARCHAR(100) NOT NULL,
s_o VARCHAR(100) NOT NULL,
note VARCHAR(100) NOT NULL,
stat VARCHAR(100) NOT NULL
)";
if ($con->query($sql_docu) === TRUE) {
   // echo "Table MyGuests created successfully";
} else {
   // echo "Error creating table: " . $con->error;
}

if ($con->query($sql_tools) === TRUE) {
    //echo "Table MyGuests created successfully";
} else {
  //  echo "Error creating table: " . $con->error;
}
if ($con->query($sql_main) === TRUE) {
    //echo "Table MyGuests created successfully";
} else {
    //echo "Error creating table: " . $con->error;
}
?>