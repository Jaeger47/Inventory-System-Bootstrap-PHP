DROP TABLE documents;

CREATE TABLE `documents` (
  `id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `p_o` varchar(100) NOT NULL,
  `s_o` varchar(100) NOT NULL,
  `del` varchar(100) NOT NULL,
  `rack` varchar(100) NOT NULL,
  `rev_date` date DEFAULT NULL,
  `del_date` date DEFAULT NULL,
  `del_by` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `path` varchar(100) NOT NULL,
  `name_2` varchar(100) NOT NULL,
  `path_2` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO documents VALUES("1","PO 2323","SO 2323","","RK 2323","1998-03-03","","","","Non-Delivered","01-IntroductionNotes.pdf","documents/receive/01-IntroductionNotes.pdf","",""); 



DROP TABLE main;

CREATE TABLE `main` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_tools` int(255) NOT NULL,
  `tol_date` date DEFAULT NULL,
  `rev_date` varchar(100) DEFAULT NULL,
  `bor_by` varchar(100) NOT NULL,
  `s_o` varchar(100) NOT NULL,
  `note` varchar(100) NOT NULL,
  `stat` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE tools;

CREATE TABLE `tools` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `tbl_1` varchar(100) NOT NULL,
  `tbl_2` varchar(100) NOT NULL,
  `tbl_3` varchar(100) NOT NULL,
  `tbl_4` varchar(100) NOT NULL,
  `tbl_5` varchar(100) NOT NULL,
  `tbl_6` varchar(100) NOT NULL,
  `tbl_7` varchar(100) NOT NULL,
  `tbl_8` varchar(100) NOT NULL,
  `tbl_9` varchar(100) NOT NULL,
  `tbl_10` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




