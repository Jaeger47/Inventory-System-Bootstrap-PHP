<?php 

    // First we execute our common code to connection to the database and start the session 
    require("common.php"); 
     
    // At the top of the page we check to see whether the user is logged in or not 
    if(empty($_SESSION['user'])) 
    { 
        // If they are not, we redirect them to the login page. 
        header("Location: index_.php"); 
         
        // Remember that this die statement is absolutely critical.  Without it, 
        // people can view your members-only content without logging in. 
        die("Redirecting to index_.php"); 
    } 
     
    // Everything below this point in the file is secured by the login system 
     
    // We can display the user's username to them by reading it from the session array.  Remember that because 
    // a username is user submitted content we must use htmlentities on it before displaying it to the user. 
?> 
<?php
//including the database connection file
include_once("startup_config.php");

//getting id of the data from url
$id_url = $_GET['id'];

//deleting the row from table

$result_select = mysqli_query($con, "SELECT * FROM documents WHERE id=$id_url");
$res = mysqli_fetch_array($result_select);


		
		$file_Path = $res['path'];
		$file_Path_2 = $res['path_2'];
		
		if(file_exists($file_Path)){
			unlink($file_Path);
			
		}
		
		if(file_exists($file_Path_2)){
			unlink($file_Path_2);
			
		}
	
$result = mysqli_query($con, "DELETE FROM documents WHERE id=$id_url");
//redirecting to the display page (index.php in our case)
header("Location:index.php");
?>

