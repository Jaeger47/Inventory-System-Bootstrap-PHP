<?php 

    // First we execute our common code to connection to the database and start the session 
    require("common.php"); 
     
    // At the top of the page we check to see whether the user is logged in or not 
    if(empty($_SESSION['user'])) 
    { 
        // If they are not, we redirect them to the login page. 
        header("Location: index_.php"); 
         
        // Remember that this die statement is absolutely critical.  Without it, 
        // people can view your members-only content without logging in. 
        die("Redirecting to index_.php"); 
    } 
     
    // Everything below this point in the file is secured by the login system 
     
    // We can display the user's username to them by reading it from the session array.  Remember that because 
    // a username is user submitted content we must use htmlentities on it before displaying it to the user. 
?> 
<?php
require 'db.php';
$id = $_GET['id'];
$sql = 'SELECT * FROM documents WHERE id=:id';
$statement = $connection->prepare($sql);
$statement->execute([':id' => $id ]);
$docu = $statement->fetch(PDO::FETCH_OBJ);

	
if (isset ($_POST['p_o']) && isset($_POST['s_o']) && isset($_POST['del']) && isset($_POST['rack']) && isset($_POST['status']) && isset($_POST['rev_date']) && isset($_POST['del_date']) && isset($_POST['del_by']) && isset($_POST['remarks'])) {
  $p_o = $_POST['p_o'];
  $s_o = $_POST['s_o'];
  $del = $_POST['del'];
  $rack = $_POST['rack'];
  $status = $_POST['status'];
  $rev_date = $_POST['rev_date'];
  $del_date = $_POST['del_date'];
  $del_by = $_POST['del_by'];
  $remarks = $_POST['remarks'];
  
  $sql = 'UPDATE documents SET p_o=:p_o, s_o=:s_o, del=:del, rack=:rack, status=:status, rev_date=:rev_date, del_date=:del_date, del_by=:del_by, remarks=:remarks WHERE id=:id';
  $statement = $connection->prepare($sql);
  if(empty($p_o) || empty($s_o)|| empty($rack)|| empty($del)) {
				
	
		
		//link to the previous page
		//echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
		echo"<script>alert(\"Please fill all the Fields\");</script>";
	} else {
  if ($statement->execute([':p_o' =>$p_o, ':s_o' => $s_o, ':del' => $del, ':rack' => $rack, ':status' => $status, ':rev_date' => $rev_date, ':del_date' => $del_date, ':del_by' => $del_by, ':remarks' => $remarks, ':id' => $id])) {
    header("Location: index.php");
		}
	}

}
?>
<?php
include_once("startup_config.php");
$id_url = $_GET['id'];
//$que=mysqli_query(con$, "select * from documents where id=$id_url");
$result = mysqli_query($con, "SELECT * FROM documents WHERE id=$id_url");
$res = mysqli_fetch_array($result);
?>



     
	  
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>itsi</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">iTSi</a>
				<p class="navbar-brand" style="float:left;"><?php echo "".date("M d Y").""; ?></p>
				<p class="navbar-brand" style="float:left;"><?php echo "".date("l").""; ?></p>
            </div>
            <!-- /.navbar-header -->

             <ul class="nav navbar-top-links navbar-right">
             
                    <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                       
                        <li><a href="settings.php"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>

         
        
		<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                       
                        <li>
                            <a href="index.php"><i class="glyphicon glyphicon-list"></i> Inventory</a>
                        </li>
						<li>
                            <a href="receive.php"><i class="glyphicon glyphicon-save"></i> Receive</a>
                        </li>
						
                        <li>
                            <a href="#"><i class="glyphicon glyphicon-wrench"></i> Tools<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="tools/search.php">Search</a>
                                </li>
                                <li>
                                    <a href="tools/acc.php">Accountability</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                      </ul>
                            <!-- /.nav-second-level -->
  
                </div>
                <!-- /.sidebar-collapse -->
            </div>
		</nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
						<div class="row">
	<div class="col-lg-6">
			<form method="post">
    
          <label for="P.O. Number">P.O. Number</label>
          <input type="text" value="<?= $docu->p_o; ?>" type="text" name="p_o" id="p_o" class="form-control">
     
      
          <label for="S.O Number">S.O Number</label>
          <input type="text" value="<?= $docu->s_o; ?>" name="s_o" id="s_o" class="form-control">
		  
		  <label for="Delivery Number">Delivery Number</label>
          <input type="text" value="<?= $docu->del; ?>" name="del" id="del" class="form-control">
		  
		  <label for="Rack Numbers">Rack Number</label>
          <input type="text" value="<?= $docu->rack; ?>" name="rack" id="rack" class="form-control">
		  
		  <label for="Receive Date">Receive Date</label>
          <input type="date" value="<?= $docu->rev_date; ?>" name="rev_date" id="rev_dates" class="form-control">
		  
		  <label for="Delivery Date">Delivery Date</label>
          <input type="date" value="<?= $docu->del_date; ?>" name="del_date" id="del_dates" class="form-control">
		  
		  <label for="Delivered by">Delivered by</label>
          <input type="text" value="<?= $docu->del_by; ?>" name="del_by" id="del_by" class="form-control">
		  
		  <label for="Delivered by">Remarks</label>
          <input type="text" value="<?= $docu->remarks; ?>" name="remarks" id="remarks" class="form-control">
		  
		  <label for="status">Status</label>
		  <div class="form-group">
					<select name="status" id="status" class="form-control">
						<option value="Delivered" <?php if($res['status']=="Delivered"){echo "selected";}?>>Delivered</option>
						<option value="Non-Delivered" <?php if($res['status']=="Non-Delivered"){echo "selected";}?>>Non-Delivered</option>
					</select>
			</div>
		<br/>
        
          <button type="submit" class="btn btn-info">Update</button>
      
      </form>
	  
                         
                            <!-- /.table-responsive -->
								</div>
                           </div>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
   


   
	


</html>



