<?php
/*$databaseHost = 'localhost';
$databaseName = 'itsi';
$databaseUsername = 'root';
$databasePassword = '';

$con = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); */
require 'data_db.php';
$servername = $db_host;
$username = $db_user;
$password = $db_pass;
$db = $db_pdo;

$conn = mysqli_connect($servername, $username, $password);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Create database
//$sql_itsi = "CREATE DATABASE itsi";
$sql_itsi_login = "CREATE DATABASE itsi_login";
/*if (mysqli_query($conn, $sql_itsi)) {
    //echo "Database created successfully";
} else {
    //echo "Error creating database: " . mysqli_error($conn);
}*/
if (mysqli_query($conn, $sql_itsi_login)) {
    //echo "Database created successfully";
} else {
    //echo "Error creating database: " . mysqli_error($conn);
}

mysqli_close($conn);

?>