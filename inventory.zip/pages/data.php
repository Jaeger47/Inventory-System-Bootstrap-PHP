<?php
	require 'main_config.php';
	$db_login=$data_name_login;
	$db_host=$data_host;
	$db_user=$data_user;
	$db_pass=$data_pass;
?>