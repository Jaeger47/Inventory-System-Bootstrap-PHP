<?php

	$path = 'documents/backup/backup.sql';
	header('Content-Type: application/octet-sream');
	header('Content-Disposition: attachment; filename="'.basename($path).'"');
	header('Content-Length: ' . filesize($path));
	readfile($path);

?>