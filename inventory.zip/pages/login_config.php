<?php
include('config.php');
require 'data.php';
$databaseHost = $db_host;
$databaseName = $db_login;
$databaseUsername = $db_user;
$databasePassword = $db_pass;

$con = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 


$sql_login = "CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` char(64) COLLATE utf8_unicode_ci NOT NULL,
  `salt` char(16) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `role` (`role`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1;";


$sql_auth = "INSERT INTO users (username, password, salt, role) VALUES ('admin','1ad15b4109db0efd3ab1bdb169c6551ca4d7fd24888c18fded3bb06a452026d8','5c8e431363b7da8d','emergency_pass')";



$date = date('Y-m-d');
$sql_database_data = "INSERT INTO db_tb (name, date) VALUES ('db_2018','$date')";

if ($con->query($sql_login) === TRUE) {
   // echo "Table MyGuests created successfully";
} else {
  //  echo "Error creating table: " . $db->error;
}



$dupesql = "SELECT * FROM users where (username = 'admin')";

$duperaw = mysqli_query($con, $dupesql);

if (mysqli_num_rows($duperaw) > 1) {
  //your code ...
  
}
else{
	if ($con->query($sql_auth) === TRUE) {
   // echo "Table MyGuests created successfully";
   if ($con->query($sql_database_data) === TRUE) {
   // echo "Table MyGuests created successfully";

} else {
  //  echo "Error creating table: " . $db->error;
}
  
} else {
  //  echo "Error creating table: " . $db->error;
}
}






?>

