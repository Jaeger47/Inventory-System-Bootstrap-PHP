<?php 

    // First we execute our common code to connection to the database and start the session 
    require("common.php"); 
     
    // At the top of the page we check to see whether the user is logged in or not 
    if(empty($_SESSION['user'])) 
    { 
        // If they are not, we redirect them to the login page. 
        header("Location: index_.php"); 
         
        // Remember that this die statement is absolutely critical.  Without it, 
        // people can view your members-only content without logging in. 
        die("Redirecting to index_.php"); 
    } 
     
    // Everything below this point in the file is secured by the login system 
     
    // We can display the user's username to them by reading it from the session array.  Remember that because 
    // a username is user submitted content we must use htmlentities on it before displaying it to the user. 
?> 
 <?php
//including the database connection file
include_once("startup_config.php");

if(isset($_POST['Submit'])) {	
	$r_date = mysqli_real_escape_string($con, $_POST['re_date']);
	$p = mysqli_real_escape_string($con, $_POST['po']);
	$s = mysqli_real_escape_string($con, $_POST['so']);
	$r = mysqli_real_escape_string($con, $_POST['ra']);
	$stat = mysqli_real_escape_string($con, "Non-Delivered");

	$name = $_FILES['myfile']['name'];
	$tmp_name = $_FILES['myfile']['tmp_name'];
	$location = "documents/receive/$name";
	move_uploaded_file($tmp_name, $location);
	
	// checking empty fields
	if(empty($r_date) || empty($p) || empty($s) || empty($r) || empty($name)) {
				
		
		
		//link to the previous page
		echo"<script>alert(\"Please fill all the Fields\");</script>";
		echo "<script> window.history.back();</script>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$result = mysqli_query($con, "INSERT INTO documents(rev_date,p_o,s_o,rack,name,path,status) VALUES('$r_date','$p','$s','$r','$name','$location','$stat')");
		echo "<script> location.replace(\"index.php\");</script>";
		//display success message
		//echo "<font color='green'>Data added successfully.";
		//echo "<br/><a href='index.php'>View Result</a>";
		

// This results in an error.
// The output above is before the header() call


}

	
		
		
		
	}
	
	

?>
