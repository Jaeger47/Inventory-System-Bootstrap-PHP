<?php 

    // First we execute our common code to connection to the database and start the session 
    require("../common.php"); 
     
    // At the top of the page we check to see whether the user is logged in or not 
    if(empty($_SESSION['user'])) 
    { 
        // If they are not, we redirect them to the login page. 
        header("Location: ../index_.php"); 
         
        // Remember that this die statement is absolutely critical.  Without it, 
        // people can view your members-only content without logging in. 
        die("Redirecting to ../index_.php"); 
    } 
     
    // Everything below this point in the file is secured by the login system 
     
    // We can display the user's username to them by reading it from the session array.  Remember that because 
    // a username is user submitted content we must use htmlentities on it before displaying it to the user. 
?> 
 <?php
//including the database connection file
include_once("../startup_config.php");

if(isset($_POST['Submit'])) {	
	$tol_date = mysqli_real_escape_string($con, $_POST['tol_date']);
	$bor_by = mysqli_real_escape_string($con, $_POST['bor_by']);
	$s_o = mysqli_real_escape_string($con, $_POST['s_o']);
	$note = mysqli_real_escape_string($con, $_POST['note']);
	$stat = 'Not Returned';
	
	
	$tbl_1 = mysqli_real_escape_string($con, $_POST['tbl_1']);
	$tbl_2 = mysqli_real_escape_string($con, $_POST['tbl_2']);
	$tbl_3 = mysqli_real_escape_string($con, $_POST['tbl_3']);
	$tbl_4 = mysqli_real_escape_string($con, $_POST['tbl_4']);
	$tbl_5 = mysqli_real_escape_string($con, $_POST['tbl_5']);
	$tbl_6 = mysqli_real_escape_string($con, $_POST['tbl_6']);
	$tbl_7 = mysqli_real_escape_string($con, $_POST['tbl_7']);
	$tbl_8 = mysqli_real_escape_string($con, $_POST['tbl_8']);
	$tbl_9 = mysqli_real_escape_string($con, $_POST['tbl_9']);
	$tbl_10 = mysqli_real_escape_string($con, $_POST['tbl_10']);


	// checking empty fields
	if(empty($tol_date) || empty($bor_by) || empty($s_o)) {
		//link to the previous page
		echo"<script>alert(\"Please fill all the Fields\");</script>";
		echo "<script> window.history.back();</script>";
	} else { 
		// if all the fields are filled (not empty) 
//mysqli_query($con, "INSERT INTO documents(rev_date,p_o,s_o,rack,name,path,status) VALUES('$r_date','$p','$s','$r','$name','$location','$stat')");
		//insert data to database	
		$result = mysqli_query($con, "INSERT INTO main(tol_date,bor_by,s_o,note,stat) VALUES('$tol_date','$bor_by','$s_o','$note','$stat')");
		$result_2 = mysqli_query($con, "INSERT INTO tools(tbl_1,tbl_2,tbl_3,tbl_4,tbl_5,tbl_6,tbl_7,tbl_8,tbl_9,tbl_10) VALUES('$tbl_1','$tbl_2','$tbl_3','$tbl_4','$tbl_5','$tbl_6','$tbl_7','$tbl_8','$tbl_9','$tbl_10')");
		echo "<script> location.replace(\"search.php\");</script>";
		//display success message
		//echo "<font color='green'>Data added successfully.";
		//echo "<br/><a href='index.php'>View Result</a>";
		

// This results in an error.
// The output above is before the header() call


}

	
		
		
		
	}
	
	

?>
