<?php 

    // First we execute our common code to connection to the database and start the session 
    require("../common.php"); 
     
    // At the top of the page we check to see whether the user is logged in or not 
    if(empty($_SESSION['user'])) 
    { 
        // If they are not, we redirect them to the login page. 
        header("Location: ../index_.php"); 
         
        // Remember that this die statement is absolutely critical.  Without it, 
        // people can view your members-only content without logging in. 
        die("Redirecting to ../index_.php"); 
    } 
     
    // Everything below this point in the file is secured by the login system 
     
    // We can display the user's username to them by reading it from the session array.  Remember that because 
    // a username is user submitted content we must use htmlentities on it before displaying it to the user. 
?> 
<?php

	include_once("../startup_config.php");
	$result = mysqli_query($con, "SELECT * FROM main ORDER BY id DESC");
	
	//$result = mysqli_query($con, "SELECT * FROM documents");
	$date = date('Y');
	
	

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>itsi</title>

    <!-- Bootstrap Core CSS -->
    <link href="../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../index.php">iTSi</a>
				<p class="navbar-brand" style="float:left;"><?php echo "".date("M d Y").""; ?></p>
				<p class="navbar-brand" style="float:left;"><?php echo "".date("l").""; ?></p>
            </div>
            <!-- /.navbar-header -->

             <ul class="nav navbar-top-links navbar-right">
             
                    <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                       
                        <li><a href="../settings.php"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="../logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>

         
        
		<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                       
                        <li>
                            <a href="../index.php"><i class="glyphicon glyphicon-list"></i> Inventory</a>
                        </li>
						<li>
                            <a href="../receive.php"><i class="glyphicon glyphicon-save"></i> Receive</a>
                        </li>
						
                        <li>
                            <a href="#"><i class="glyphicon glyphicon-wrench"></i> Tools<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="search.php" class="active">Search</a>
                                </li>
                                <li>
                                    <a href="acc.php">Accountability</a>
                                </li>

                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                      </ul>
                            <!-- /.nav-second-level -->
                        
                      
            
                </div>
                <!-- /.sidebar-collapse -->
            </div>
		</nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>            
										<th>Reference Number</th>
										<th>Date</th>
										<th>Borrowed By</th>
										
										<th>S.O Number</th>
                                        <th>Return Date</th>
										<th>Status</th>
										<th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
								<?php
									while($res = mysqli_fetch_array($result)) {
										$ref = $date."-".$res['id'];
										echo "<tr>";
										echo "<td><a data-toggle=\"modal\" data-target=\"#exampleModal$res[id]\" style=\"cursor:pointer;\">".$ref."</a></td>";
										echo "<td>".$res['tol_date']."</td>";
										echo "<td>".$res['bor_by']."</td>";
										//echo "<td>".$res['id']."</td>";
										echo "<td>".$res['s_o']."</td>";
										echo "<td>".$res['rev_date']."</td>";
										echo "<td>".$res['stat']."</td>";
										echo "<td align=\"center\"><a type=\"button\" class=\"btn btn-info\" href=\"edit.php?id=$res[id]\">Edit</a> <a type=\"button\" class=\"btn btn-danger\" href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td> ";
										echo "</tr>";
										
									
										echo "<!-- Modal -->";
										echo "<div class=\"modal fade\" id=\"exampleModal$res[id]\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">";
										echo  "<div class=\"modal-dialog\" role=\"document\">";
										echo    "<div class=\"modal-content\">";
										echo      "<div class=\"modal-header\">";
										//echo        "<h4 class=\"modal-title\" id=\"exampleModalLabel\">Action</h4>";
										echo        "<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">";
										echo          "<span aria-hidden=\"true\">&times;</span>";
										echo        "</button>";
										echo      "</div>";
										echo      "<div class=\"modal-body\">";
										echo        "<b>View or Return</b>";
										echo      "</div>";
										echo      "<div class=\"modal-footer\">";
										echo "<a type=\"button\" class=\"btn btn-warning\" href=\"Return.php?id=$res[id]\">Return</a> ";
										echo "<a type=\"button\" class=\"btn btn-info\" href=\"view.php?id=$res[id]\">View</a> ";
										echo      "</div>";
										echo    "</div>";
										echo  "</div>";
										echo "</div>";
									}
									?>
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>
	

</body>

</html>
