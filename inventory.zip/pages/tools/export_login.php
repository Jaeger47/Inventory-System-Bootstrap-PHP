<?php

include_once('../login_config.php');

$filename = '../documents/backup/backup_login.sql';
$handle = fopen($filename, "r+");
$contents = fread($handle,filesize($filename));


$sql = explode(';',$contents);
foreach($sql as $query){
	$result = mysqli_query($con, $query);
}

fclose($handle);
echo"<script>alert(\"Restore Completed\");</script>";
echo "<script>location.replace(\"../settings.php\");</script>";
?>