<?php 

    // First we execute our common code to connection to the database and start the session 
    require("../common.php"); 
     
    // At the top of the page we check to see whether the user is logged in or not 
    if(empty($_SESSION['user'])) 
    { 
        // If they are not, we redirect them to the login page. 
        header("Location: ../index_.php"); 
         
        // Remember that this die statement is absolutely critical.  Without it, 
        // people can view your members-only content without logging in. 
        die("Redirecting to ../index_.php"); 
    } 
     
    // Everything below this point in the file is secured by the login system 
     
    // We can display the user's username to them by reading it from the session array.  Remember that because 
    // a username is user submitted content we must use htmlentities on it before displaying it to the user. 
?> 
<?php
include_once("../startup_config.php");
if(isset($_POST['Submit']))
{	

	$id = mysqli_real_escape_string($con, $_POST['id_url']);
	
	$tbl_1 = mysqli_real_escape_string($con, $_POST['tbl_1']);
	$tbl_2 = mysqli_real_escape_string($con, $_POST['tbl_2']);
	$tbl_3 = mysqli_real_escape_string($con, $_POST['tbl_3']);
	$tbl_4 = mysqli_real_escape_string($con, $_POST['tbl_4']);
	$tbl_5 = mysqli_real_escape_string($con, $_POST['tbl_5']);
	$tbl_6 = mysqli_real_escape_string($con, $_POST['tbl_6']);
	$tbl_7 = mysqli_real_escape_string($con, $_POST['tbl_7']);
	$tbl_8 = mysqli_real_escape_string($con, $_POST['tbl_8']);
	$tbl_9 = mysqli_real_escape_string($con, $_POST['tbl_9']);
	$tbl_10 = mysqli_real_escape_string($con, $_POST['tbl_10']);
	$rev_date = mysqli_real_escape_string($con, $_POST['rev_date']);
		
	// checking empty fields
	//$result = mysqli_query($con, "SELECT * FROM main WHERE id=$id");
	//$res = mysqli_fetch_array($result);
	
		//updating the table
		$result = mysqli_query($con, "UPDATE tools SET tbl_1='$tbl_1',tbl_2='$tbl_2',tbl_3='$tbl_3',tbl_4='$tbl_4',tbl_5='$tbl_5',tbl_6='$tbl_6',tbl_7='$tbl_7',tbl_8='$tbl_8',tbl_9='$tbl_9',tbl_10='$tbl_10' WHERE id=$id");
		$result_2 = mysqli_query($con, "UPDATE main SET rev_date='$rev_date' WHERE id=$id");
		
		if(!empty($rev_date)){
			$result_3 = mysqli_query($con, "UPDATE main SET stat='Returned' WHERE id=$id");
		}
		else{
			echo"<script>alert(\"Not Successful\");</script>";
		}
		
		
		//redirectig to the display page. In our case, it is index.php
		header("Location: search.php");
	}
	else{
		echo"<script>alert(\"Not Successful\");</script>";
	}
?>