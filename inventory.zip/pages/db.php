<?php
require 'data_db.php';
$dsn = 'mysql:dbname='.$db_pdo.';host='.$db_host;
$username = $db_user;
$password = $db_pass;
$options = [];
try {
$connection = new PDO($dsn, $username, $password, $options);
} catch(PDOException $e) {

}